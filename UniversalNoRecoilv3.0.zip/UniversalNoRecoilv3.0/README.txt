Title: UniCoil			|
Author: Demon
Date: 05/07/2023		        |
Version: v3.0	                |
________________________________

HOW TO USE
- Set your desired settings either by adjusting "settings.ini" manually or by using the GUI in "CONFIGURATION" mode
- Set desired mode and toggle desired settings
